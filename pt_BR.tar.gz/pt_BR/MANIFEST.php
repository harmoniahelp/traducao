<?php return array (
  'Build-Date' => 'Mon, 12 Jun 23 16:08:01 +0000',
  'Phrases-Version' => NULL,
  'Build-Version' => 'v1.17.3-20-ge4bfb00d',
  'Build-Major-Version' => '1.17',
  'Language' => NULL,
  'Id' => 'lang:pt_BR',
  'Last-Revision' => NULL,
  'Version' => 0,
);